"use client";

import React, { useState } from "react";
import ZetaLayout from "./components/zeta/ZetaLayout";

const Home = () => {
  return (
    <div className="flex flex-col h-screen w-screen">
      <ZetaLayout />
    </div>
  );
};

export default Home;
